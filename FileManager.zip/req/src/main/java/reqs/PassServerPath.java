package reqs;

import java.io.Serializable;

public record PassServerPath(String currentServerPath) implements Serializable {
}

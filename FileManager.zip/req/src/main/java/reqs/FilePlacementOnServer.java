package reqs;

import java.io.Serializable;

public record FilePlacementOnServer(String string) implements Serializable {
}

package reqs;

import java.io.Serializable;

public record ServerRequestNegative(String string) implements Serializable {
}

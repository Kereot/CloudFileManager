package reqs;

import java.io.Serializable;

public record ServerFinishedTask() implements Serializable {
}

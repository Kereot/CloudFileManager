module req {
    exports reqs;
}